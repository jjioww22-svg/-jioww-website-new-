import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  MessageCircle, 
  X, 
  Send, 
  Bot, 
  User,
  Sparkles,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Languages
} from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  suggestions?: string[];
}

type Language = 'en' | 'hi' | 'pa' | 'ne' | 'fil';

interface AIChatbotProps {
  isOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  initialMessage?: string;
}

const languageNames = {
  en: 'English',
  hi: 'हिंदी',
  pa: 'ਪੰਜਾਬੀ',
  ne: 'नेपाली',
  fil: 'Filipino'
};

const languageFlags = {
  en: '🇬🇧',
  hi: '🇮🇳',
  pa: '🇮🇳',
  ne: '🇳🇵',
  fil: '🇵🇭'
};

// Comprehensive Language-specific translations
const translations = {
  greeting: {
    en: "Hello! 👋 Welcome to JioWW Global - your trusted immigration consultancy.\n\n🎉 FREE Assessment & Europe Interviews!\n\n📱 WhatsApp your CV to +971 50 181 8023 for review - our expert will contact you back very soon!\n\nHow can I assist you today?",
    hi: "नमस्ते! 👋 JioWW Global में आपका स्वागत है - आपकी विश्वसनीय इमिग्रेशन कंसल्टेंसी।\n\n🎉 मुफ्त मूल्यांकन और यूरोप साक्षात्कार!\n\n📱 समीक्षा के लिए अपना CV +971 50 181 8023 पर व्हाट्सएप करें - हमारे विशेषज्ञ जल्द ही आपसे संपर्क करेंगे!\n\nआज मैं आपकी कैसे मदद कर सकता हूं?",
    pa: "ਸਤ ਸ੍ਰੀ ਅਕਾਲ! 👋 JioWW Global ਵਿੱਚ ਤੁਹਾਡਾ ਸੁਆਗਤ ਹੈ - ਤੁਹਾਡੀ ਭਰੋਸੇਮੰਦ ਇਮੀਗ੍ਰੇਸ਼ਨ ਸਲਾਹਕਾਰ।\n\n🎉 ਮੁਫਤ ਮੁਲਾਂਕਣ ਅਤੇ ਯੂਰਪ ਇੰਟਰਵਿਊ!\n\n📱 ਸਮੀਖਿਆ ਲਈ ਆਪਣਾ CV +971 50 181 8023 'ਤੇ ਵਟਸਐਪ ਕਰੋ - ਸਾਡੇ ਮਾਹਰ ਜਲਦੀ ਹੀ ਤੁਹਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰਨਗੇ!\n\nਅੱਜ ਮੈਂ ਤੁਹਾਡੀ ਕਿਵੇਂ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ?",
    ne: "नमस्कार! 👋 JioWW Global मा तपाईंलाई स्वागत छ - तपाईंको भरपर्दो अध्यागमन परामर्श।\n\n🎉 निःशुल्क मूल्याङ्कन र युरोप अन्तर्वार्ता!\n\n📱 समीक्षाको लागि आफ्नो CV +971 50 181 8023 मा व्हाट्सएप गर्नुहोस् - हाम्रो विशेषज्ञले चाँडै तपाईंलाई सम्पर्क गर्नेछ!\n\nआज म तपाईंलाई कसरी मद्दत गर्न सक्छु?",
    fil: "Kumusta! 👋 Maligayang pagdating sa JioWW Global - ang inyong pinagkakatiwalaang immigration consultancy.\n\n🎉 LIBRENG Assessment & Europe Interviews!\n\n📱 I-WhatsApp ang inyong CV sa +971 50 181 8023 para sa review - makikipag-ugnayan sa inyo ang aming eksperto sa lalong madaling panahon!\n\nPaano ko kayo matutulungan ngayong araw?"
  },
  services: {
    en: "🌟 JioWW Global offers comprehensive immigration and study visa services:\n\n📍 Immigration Programs:\n• Canada PR (Express Entry, PNP)\n• Australia PR (Skilled Migration)\n• European Work Permits (Gulf Candidates Only):\n  - Slovenia: Truck Drivers, Welders\n  - Malta & Croatia: Hospitality, Trade Professions, Operators\n\n🎓 Study Visa Services:\n• Canada, Australia, UK, Germany\n\n💼 Our Services Include:\n• Professional consultation & eligibility assessment\n• Document preparation guidance\n• Application support\n• Employer connections\n\n📱 WhatsApp CV: +971 50 181 8023",
    hi: "🌟 JioWW Global व्यापक इमिग्रेशन और स्टडी वीजा सेवाएं प्रदान करता है:\n\n📍 इमिग्रेशन कार्यक्रम:\n• कनाडा PR (एक्सप्रेस एंट्री, PNP)\n• ऑस्ट्रेलिया PR (स्किल्ड माइग्रेशन)\n• यूरोपीय वर्क परमिट (केवल गल्फ उम्मीदवार):\n  - स्लोवेनिया: ट्रक ड्राइवर, वेल्डर\n  - माल्टा और क्रोएशिया: आतिथ्य, व्यापार पेशे, ऑपरेटर\n\n🎓 स्टडी वीजा सेवाएं:\n• कनाडा, ऑस्ट्रेलिया, यूके, जर्मनी\n\n💼 हमारी सेवाओं में शामिल:\n• पेशेवर परामर्श और पात्रता मूल्यांकन\n• दस्तावेज़ तैयारी मार्गदर्शन\n• आवेदन सहायता\n• नियोक्ता कनेक्शन\n\n📱 व्हाट्सएप CV: +971 50 181 8023",
    pa: "🌟 JioWW Global ਵਿਆਪਕ ਇਮੀਗ੍ਰੇਸ਼ਨ ਅਤੇ ਸਟੱਡੀ ਵੀਜ਼ਾ ਸੇਵਾਵਾਂ ਪ੍ਰਦਾਨ ਕਰਦਾ ਹੈ:\n\n📍 ਇਮੀਗ੍ਰੇਸ਼ਨ ਪ੍ਰੋਗਰਾਮ:\n• ਕੈਨੇਡਾ PR (ਐਕਸਪ੍ਰੈਸ ਐਂਟਰੀ, PNP)\n• ਆਸਟ੍ਰੇਲੀਆ PR (ਸਕਿੱਲਡ ਮਾਈਗ੍ਰੇਸ਼ਨ)\n• ਯੂਰਪੀਅਨ ਵਰਕ ਪਰਮਿਟ (ਸਿਰਫ ਗਲਫ ਉਮੀਦਵਾਰ):\n  - ਸਲੋਵੇਨੀਆ: ਟਰੱਕ ਡਰਾਈਵਰ, ਵੈਲਡਰ\n  - ਮਾਲਟਾ ਅਤੇ ਕ੍ਰੋਏਸ਼ੀਆ: ਹੋਸਪਿਟੈਲਿਟੀ, ਟਰੇਡ ਪ੍ਰੋਫੈਸ਼ਨਜ਼, ਓਪਰੇਟਰ\n\n🎓 ਸਟੱਡੀ ਵੀਜ਼ਾ ਸੇਵਾਵਾਂ:\n• ਕੈਨੇਡਾ, ਆਸਟ੍ਰੇਲੀਆ, ਯੂਕੇ, ਜਰਮਨੀ\n\n💼 ਸਾਡੀਆਂ ਸੇਵਾਵਾਂ ਵਿੱਚ ਸ਼ਾਮਲ:\n• ਪੇਸ਼ੇਵਰ ਸਲਾਹ ਅਤੇ ਯੋਗਤਾ ਮੁਲਾਂਕਣ\n• ਦਸਤਾਵੇਜ਼ ਤਿਆਰੀ ਮਾਰਗਦਰਸ਼ਨ\n• ਅਰਜ਼ੀ ਸਹਾਇਤਾ\n• ਰੁਜ਼ਗਾਰਦਾਤਾ ਕਨੈਕਸ਼ਨ\n\n📱 ਵਟਸਐਪ CV: +971 50 181 8023",
    ne: "🌟 JioWW Global व्यापक अध्यागमन र अध्ययन भिसा सेवाहरू प्रदान गर्दछ:\n\n📍 अध्यागमन कार्यक्रमहरू:\n• क्यानाडा PR (एक्सप्रेस एन्ट्री, PNP)\n• अष्ट्रेलिया PR (दक्ष माइग्रेसन)\n• युरोपेली कार्य अनुमति (खाडी उम्मेदवार मात्र):\n  - स्लोभेनिया: ट्रक चालक, वेल्डर\n  - माल्टा र क्रोएशिया: आतिथ्य, व्यापार पेशा, अपरेटर\n\n🎓 अध्ययन भिसा सेवाहरू:\n• क्यानाडा, अष्ट्रेलिया, बेलायत, जर्मनी\n\n💼 हाम्रा सेवाहरूमा समावेश:\n• व्यावसायिक परामर्श र योग्यता मूल्याङ्कन\n• कागजात तयारी मार्गदर्शन\n• आवेदन सहयोग\n• रोजगारदाता जडान\n\n📱 व्हाट्सएप CV: +971 50 181 8023",
    fil: "🌟 Nag-aalok ang JioWW Global ng komprehensibong immigration at study visa services:\n\n📍 Immigration Programs:\n• Canada PR (Express Entry, PNP)\n• Australia PR (Skilled Migration)\n• European Work Permits (Gulf Candidates Lamang):\n  - Slovenia: Truck Drivers, Welders\n  - Malta & Croatia: Hospitality, Trade Professions, Operators\n\n🎓 Study Visa Services:\n• Canada, Australia, UK, Germany\n\n💼 Kasama sa aming mga serbisyo:\n• Propesyonal na konsultasyon at pagsusuri ng eligibility\n• Gabay sa paghahanda ng dokumento\n• Suporta sa aplikasyon\n• Koneksyon sa employer\n\n📱 WhatsApp CV: +971 50 181 8023"
  },
  contact: {
    en: "📞 Contact JioWW Global\n\nDubai Office:\n📍 25th Floor, Al Saqr Business Tower\nSheikh Zayed Road, DIFC/ Trade Center-2nd.\n(Between Metro stations of Emirates tower/Financial center)\nDubai, UAE\n📱 WhatsApp: +971 50 181 8023\n🕐 Mon-Sat: 11:00 AM - 8:00 PM (GST)\n\nIndia Office (Chandigarh):\n📍 First Floor, SCO-106, Sector-47 C\nChandigarh, India\n📱 WhatsApp: +91 62808 08887\n🕐 Mon-Sat: 10:00 AM - 7:00 PM (IST)\n\nEmail:\n✉️ career@jioww.com",
    hi: "📞 JioWW Global से संपर्क करें\n\nदुबई कार्यालय:\n📍 25th Floor, Al Saqr Business Tower\nSheikh Zayed Road, DIFC/ Trade Center-2nd.\n(Emirates tower/Financial center मेट्रो स्टेशनों के बीच)\nदुबई, यूएई\n📱 व्हाट्सएप: +971 50 181 8023\n🕐 सोम-शनि: 11:00 AM - 8:00 PM (GST)\n\nभारत कार्यालय (चंडीगढ़):\n📍 First Floor, SCO-106, Sector-47 C\nचंडीगढ़, भारत\n📱 व्हाट्सएप: +91 62808 08887\n🕐 सोम-शनि: 10:00 AM - 7:00 PM (IST)\n\nईमेल:\n✉️ career@jioww.com",
    pa: "📞 JioWW Global ਨਾਲ ਸੰਪਰਕ ਕਰੋ\n\nਦੁਬਈ ਦਫ਼ਤਰ:\n📍 25th Floor, Al Saqr Business Tower\nSheikh Zayed Road, DIFC/ Trade Center-2nd.\n(Emirates tower/Financial center ਮੈਟਰੋ ਸਟੇਸ਼ਨਾਂ ਦੇ ਵਿਚਕਾਰ)\nਦੁਬਈ, ਯੂਏਈ\n📱 ਵਟਸਐਪ: +971 50 181 8023\n🕐 ਸੋਮ-ਸ਼ਨੀ: 11:00 AM - 8:00 PM (GST)\n\nਭਾਰਤ ਦਫ਼ਤਰ (ਚੰਡੀਗੜ੍ਹ):\n📍 First Floor, SCO-106, Sector-47 C\nਚੰਡੀਗੜ੍ਹ, ਭਾਰਤ\n📱 ਵਟਸਐਪ: +91 62808 08887\n🕐 ਸੋਮ-ਸ਼ਨੀ: 10:00 AM - 7:00 PM (IST)\n\nਈਮੇਲ:\n✉️ career@jioww.com",
    ne: "📞 JioWW Global सँग सम्पर्क गर्नुहोस्\n\nदुबई कार्यालय:\n📍 25th Floor, Al Saqr Business Tower\nSheikh Zayed Road, DIFC/ Trade Center-2nd.\n(Emirates tower/Financial center मेट्रो स्टेशनहरू बीच)\nदुबई, यूएई\n📱 व्हाट्सएप: +971 50 181 8023\n🕐 सोम-शनि: 11:00 AM - 8:00 PM (GST)\n\nभारत कार्यालय (चण्डीगढ):\n📍 First Floor, SCO-106, Sector-47 C\nचण्डीगढ, भारत\n📱 व्हाट्सएप: +91 62808 08887\n🕐 सोम-शनि: 10:00 AM - 7:00 PM (IST)\n\nइमेल:\n✉️ career@jioww.com",
    fil: "📞 Kontakin ang JioWW Global\n\nDubai Office:\n📍 25th Floor, Al Saqr Business Tower\nSheikh Zayed Road, DIFC/ Trade Center-2nd.\n(Between Metro stations of Emirates tower/Financial center)\nDubai, UAE\n📱 WhatsApp: +971 50 181 8023\n🕐 Lun-Sab: 11:00 AM - 8:00 PM (GST)\n\nIndia Office (Chandigarh):\n📍 First Floor, SCO-106, Sector-47 C\nChandigarh, India\n📱 WhatsApp: +91 62808 08887\n🕐 Lun-Sab: 10:00 AM - 7:00 PM (IST)\n\nEmail:\n✉️ career@jioww.com"
  },
  canada: {
    en: "🇨🇦 CANADA PR PROGRAMS\n\n1️⃣ EXPRESS ENTRY (Federal)\n• CRS Score: 470+ points competitive\n• Programs: FSWP, CEC, FSTP\n• Requirements: IELTS, ECA, work experience\n\n2️⃣ PROVINCIAL NOMINEE PROGRAM (PNP)\n• Adds 600 CRS points\n• Popular: Ontario, BC, Alberta, Saskatchewan\n• Enhanced opportunities with job offer\n\n3️⃣ ATLANTIC IMMIGRATION\n• Lower requirements (CLB 4-5)\n• 4 provinces: NS, NB, PEI, NL\n• No LMIA needed\n\n📊 Latest News: 3,700 ITAs at CRS 536\n🎯 Target: 485,000 immigrants in 2025\n\n📱 WhatsApp CV: +971 50 181 8023",
    hi: "🇨🇦 कनाडा PR कार्यक्रम\n\n1️⃣ एक्सप्रेस एंट्री (संघीय)\n• CRS स्कोर: 470+ अंक प्रतिस्पर्धी\n• कार्यक्रम: FSWP, CEC, FSTP\n• आवश्यकताएं: IELTS, ECA, कार्य अनुभव\n\n2️⃣ प्रांतीय नामांकित कार्यक्रम (PNP)\n• 600 CRS अंक जोड़ता है\n• लोकप्रिय: ओंटारियो, BC, अल्बर्टा, सस्केचेवान\n• नौकरी के साथ बेहतर अवसर\n\n3️⃣ अटलांटिक इमिग्रेशन\n• कम आवश्यकताएं (CLB 4-5)\n• 4 प्रांत: NS, NB, PEI, NL\n• LMIA की जरूरत नहीं\n\n📊 नवीनतम समाचार: CRS 536 पर 3,700 ITA\n🎯 लक्ष्य: 2025 में 485,000 आप्रवासी\n\n📱 व्हाट्सएप CV: +971 50 181 8023",
    pa: "🇨🇦 ਕੈਨੇਡਾ PR ਪ੍ਰੋਗਰਾਮ\n\n1️⃣ ਐਕਸਪ੍ਰੈਸ ਐਂਟਰੀ (ਸੰਘੀ)\n• CRS ਸਕੋਰ: 470+ ਅੰਕ ਮੁਕਾਬਲੇਬਾਜ਼\n• ਪ੍ਰੋਗਰਾਮ: FSWP, CEC, FSTP\n• ਲੋੜਾਂ: IELTS, ECA, ਕੰਮ ਦਾ ਤਜਰਬਾ\n\n2️⃣ ਪ੍ਰੋਵਿੰਸ਼ੀਅਲ ਨਾਮਜ਼ਦ ਪ੍ਰੋਗਰਾਮ (PNP)\n• 600 CRS ਅੰਕ ਜੋੜਦਾ ਹੈ\n• ਪ੍ਰਸਿੱਧ: ਓਨਟਾਰੀਓ, BC, ਅਲਬਰਟਾ, ਸਸਕੈਚਵਨ\n• ਨੌਕਰੀ ਨਾਲ ਬਿਹਤਰ ਮੌਕੇ\n\n3️⃣ ਐਟਲਾਂਟਿਕ ਇਮੀਗ੍ਰੇਸ਼ਨ\n• ਘੱਟ ਲੋੜਾਂ (CLB 4-5)\n• 4 ਸੂਬੇ: NS, NB, PEI, NL\n• LMIA ਦੀ ਲੋੜ ਨਹੀਂ\n\n📊 ਨਵੀਨਤਮ ਖ਼ਬਰ: CRS 536 'ਤੇ 3,700 ITA\n🎯 ਟੀਚਾ: 2025 ਵਿੱਚ 485,000 ਪਰਵਾਸੀ\n\n📱 ਵਟਸਐਪ CV: +971 50 181 8023",
    ne: "🇨🇦 क्यानाडा PR कार्यक्रमहरू\n\n1️⃣ एक्सप्रेस एन्ट्री (संघीय)\n• CRS अंक: 470+ अंक प्रतिस्पर्धी\n• कार्यक्रमहरू: FSWP, CEC, FSTP\n• आवश्यकताहरू: IELTS, ECA, कार्य अनुभव\n\n2️⃣ प्रान्तीय मनोनीत कार्यक्रम (PNP)\n• 600 CRS अंक थप्छ\n• लोकप्रिय: ओन्टारियो, BC, अल्बर्टा, सास्काचेवान\n• जागिरसँग राम्रो अवसर\n\n3️⃣ एट्लान्टिक अध्यागमन\n• कम आवश्यकताहरू (CLB 4-5)\n• 4 प्रान्तहरू: NS, NB, PEI, NL\n• LMIA आवश्यक छैन\n\n📊 नवीनतम समाचार: CRS 536 मा 3,700 ITA\n🎯 लक्ष्य: 2025 मा 485,000 आप्रवासी\n\n📱 व्हाट्सएप CV: +971 50 181 8023",
    fil: "🇨🇦 CANADA PR PROGRAMS\n\n1️⃣ EXPRESS ENTRY (Federal)\n• CRS Score: 470+ puntos competitive\n• Programs: FSWP, CEC, FSTP\n• Requirements: IELTS, ECA, work experience\n\n2️⃣ PROVINCIAL NOMINEE PROGRAM (PNP)\n• Nagdadagdag ng 600 CRS points\n• Popular: Ontario, BC, Alberta, Saskatchewan\n• Mas magandang opportunities sa job offer\n\n3️⃣ ATLANTIC IMMIGRATION\n• Mas mababang requirements (CLB 4-5)\n• 4 provinces: NS, NB, PEI, NL\n• Walang LMIA needed\n\n📊 Latest News: 3,700 ITAs sa CRS 536\n🎯 Target: 485,000 immigrants sa 2025\n\n📱 WhatsApp CV: +971 50 181 8023"
  },
  australia: {
    en: "🇦🇺 AUSTRALIA PR PROGRAMS\n\n1️⃣ SUBCLASS 189 (Skilled Independent)\n• Points: 65+ (Competitive: 85+)\n• No sponsorship needed\n• Occupations: IT, Engineering, Healthcare\n\n2️⃣ SUBCLASS 190 (State Nominated)\n• Points: 65+ + State nomination\n• Live in nominating state\n• Extra 5 points for nomination\n\n3️⃣ SUBCLASS 491 (Regional)\n• 5-year visa, pathway to PR\n• Lower points requirement\n• Cities: Perth, Adelaide, Gold Coast\n\n📊 Latest: 190,000 skilled visas in 2025-26\n✅ Requirements: Skills assessment, English, Points test\n\n📱 WhatsApp CV: +971 50 181 8023",
    hi: "🇦🇺 ऑस्ट्रेलिया PR कार्यक्रम\n\n1️⃣ सबक्लास 189 (स्किल्ड इंडिपेंडेंट)\n• अंक: 65+ (प्रतिस्पर्धी: 85+)\n• स्पॉन्सरशिप की जरूरत नहीं\n• व्यवसाय: IT, इंजीनियरिंग, हेल्थकेयर\n\n2️⃣ सबक्लास 190 (राज्य नामांकित)\n• अंक: 65+ + राज्य नामांकन\n• नामांकित राज्य में रहें\n• नामांकन के लिए अतिरिक्त 5 अंक\n\n3️⃣ सबक्लास 491 (क्षेत्रीय)\n• 5-वर्षीय वीज़ा, PR का रास्ता\n• कम अंक आवश्यकता\n• शहर: Perth, Adelaide, Gold Coast\n\n📊 नवीनतम: 2025-26 में 190,000 स्किल्ड वीज़ा\n✅ आवश्यकताएं: स्किल मूल्यांकन, अंग्रेजी, अंक परीक्षण\n\n📱 व्हाट्सएप CV: +971 50 181 8023",
    pa: "🇦🇺 ਆਸਟ੍ਰੇਲੀਆ PR ਪ੍ਰੋਗਰਾਮ\n\n1️⃣ ਸਬਕਲਾਸ 189 (ਸਕਿੱਲਡ ਇੰਡੀਪੈਂਡੈਂਟ)\n• ਅੰਕ: 65+ (ਮੁਕਾਬਲੇਬਾਜ਼: 85+)\n• ਸਪਾਂਸਰਸ਼ਿਪ ਦੀ ਲੋੜ ਨਹੀਂ\n• ਪੇਸ਼ੇ: IT, ਇੰਜੀਨੀਅਰਿੰਗ, ਸਿਹਤ ਸੰਭਾਲ\n\n2️⃣ ਸਬਕਲਾਸ 190 (ਰਾਜ ਨਾਮਜ਼ਦ)\n• ਅੰਕ: 65+ + ਰਾਜ ਨਾਮਜ਼ਦਗੀ\n• ਨਾਮਜ਼ਦ ਰਾਜ ਵਿੱਚ ਰਹੋ\n• ਨਾਮਜ਼ਦਗੀ ਲਈ ਵਾਧੂ 5 ਅੰਕ\n\n3️⃣ ਸਬਕਲਾਸ 491 (ਖੇਤਰੀ)\n• 5-ਸਾਲ ਵੀਜ਼ਾ, PR ਦਾ ਰਸਤਾ\n• ਘੱਟ ਅੰਕ ਲੋੜ\n• ਸ਼ਹਿਰ: Perth, Adelaide, Gold Coast\n\n📊 ਨਵੀਨਤਮ: 2025-26 ਵਿੱਚ 190,000 ਸਕਿੱਲਡ ਵੀਜ਼ਾ\n✅ ਲੋੜਾਂ: ਸਕਿੱਲ ਮੁਲਾਂਕਣ, ਅੰਗਰੇਜ਼ੀ, ਅੰਕ ਟੈਸਟ\n\n📱 ਵਟਸਐਪ CV: +971 50 181 8023",
    ne: "🇦🇺 अष्ट्रेलिया PR कार्यक्रमहरू\n\n1️⃣ सबक्लास 189 (दक्ष स्वतन्त्र)\n• अंक: 65+ (प्रतिस्पर्धी: 85+)\n• प्रायोजन आवश्यक छैन\n• पेशाहरू: IT, इन्जिनियरिङ, स्वास्थ्य सेवा\n\n2️⃣ सबक्लास 190 (राज्य मनोनीत)\n• अंक: 65+ + राज्य मनोनयन\n• मनोनीत राज्यमा बस्नुहोस्\n• मनोनयनको लागि थप 5 अंक\n\n3️⃣ सबक्लास 491 (क्षेत्रीय)\n• 5-वर्षीय भिसा, PR को बाटो\n• कम अंक आवश्यकता\n• शहरहरू: Perth, Adelaide, Gold Coast\n\n📊 नवीनतम: 2025-26 मा 190,000 दक्ष भिसा\n✅ आवश्यकताहरू: सीप मूल्याङ्कन, अंग्रेजी, अंक परीक्षा\n\n📱 व्हाट्सएप CV: +971 50 181 8023",
    fil: "🇦🇺 AUSTRALIA PR PROGRAMS\n\n1️⃣ SUBCLASS 189 (Skilled Independent)\n• Points: 65+ (Competitive: 85+)\n• Walang sponsorship needed\n• Occupations: IT, Engineering, Healthcare\n\n2️⃣ SUBCLASS 190 (State Nominated)\n• Points: 65+ + State nomination\n• Tumira sa nominating state\n• Extra 5 points para sa nomination\n\n3️⃣ SUBCLASS 491 (Regional)\n• 5-taon visa, pathway sa PR\n• Mas mababang points requirement\n• Cities: Perth, Adelaide, Gold Coast\n\n📊 Latest: 190,000 skilled visas sa 2025-26\n✅ Requirements: Skills assessment, English, Points test\n\n📱 WhatsApp CV: +971 50 181 8023"
  },
  europe: {
    en: "🇪🇺 EUROPEAN WORK PERMITS (Gulf Candidates Only)\n\n1️⃣ SLOVENIA\n• Truck Drivers (Cat C/CE license, 2+ years exp)\n• Welders (TIG/MIG certified, 3+ years exp)\n• Benefits: EU wages, accommodation, health insurance\n• Interview: English (video call)\n• ✅ Gulf Candidates Only\n\n2️⃣ MALTA\n• Hospitality (hotels, restaurants, 2+ years)\n• Trade Professions (electricians, plumbers, 3+ years)\n• Operators (heavy machinery, certified, 2+ years)\n• Benefits: English-speaking, EU permit, family visa\n• Interview: English (mandatory)\n• ✅ Gulf Candidates Only\n\n3️⃣ CROATIA\n• Hospitality (tourism sector, 2+ years)\n• Trade Professions (construction, 3+ years)\n• Operators (equipment certified, 2+ years)\n• Benefits: Coastal locations, EU residence\n• Interview: English required\n• ✅ Gulf Candidates Only\n\n📋 Process: CV submission → Interview → Documents → Job offer → Visa\n📱 WhatsApp CV: +971 50 181 8023",
    hi: "🇪🇺 यूरोपीय वर्क परमिट\n⚠️ महत्वपूर्ण: केवल गल्फ उम्मीदवार\n\n1️⃣ स्लोवेनिया\n• ट्रक ड्राइवर\n• वेल्डर\n• EU एक्सेस और लाभ\n• ✅ केवल गल्फ उम्मीदवार\n\n2️⃣ माल्टा\n• आतिथ्य पेशेवर\n• व्यापार पेशे\n• ऑपरेटर\n• ✅ केवल गल्फ उम्मीदवार\n\n3️⃣ क्रोएशिया\n• आतिथ्य पेशेवर\n• व्यापार पेशे\n• ऑपरेटर\n• ✅ केवल गल्फ उम्मीदवार\n\n📱 व्हाट्सएप CV: +971 50 181 8023",
    pa: "🇪🇺 ਯੂਰਪੀਅਨ ਵਰਕ ਪਰਮਿਟ\n⚠️ ਮਹੱਤਵਪੂਰਨ: ਸਿਰਫ ਗਲਫ ਉਮੀਦਵਾਰ\n\n1️⃣ ਸਲੋਵੇਨੀਆ\n• ਟਰੱਕ ਡਰਾਈਵਰ\n• ਵੈਲਡਰ\n• EU ਐਕਸੈਸ ਅਤੇ ਲਾਭ\n• ✅ ਸਿਰਫ ਗਲਫ ਉਮੀਦਵਾਰ\n\n2️⃣ ਮਾਲਟਾ\n• ਹੋਸਪਿਟੈਲਿਟੀ ਪ੍ਰੋਫੈਸ਼ਨਲ\n• ਟਰੇਡ ਪ੍ਰੋਫੈਸ਼ਨਜ਼\n• ਓਪਰੇਟਰ\n• ✅ ਸਿਰਫ ਗਲਫ ਉਮੀਦਵਾਰ\n\n3️⃣ ਕ੍ਰੋਏਸ਼ੀਆ\n• ਹੋਸਪਿਟੈਲਿਟੀ ਪ੍ਰੋਫੈਸ਼ਨਲ\n• ਟਰੇਡ ਪ੍ਰੋਫੈਸ਼ਨਜ਼\n• ਓਪਰੇਟਰ\n• ✅ ਸਿਰਫ ਗਲਫ ਉਮੀਦਵਾਰ\n\n📱 ਵਟਸਐਪ CV: +971 50 181 8023",
    ne: "🇪🇺 युरोपेली कार्य अनुमतिहरू\n⚠️ महत्वपूर्ण: खाडी उम्मेदवार मात्र\n\n1️⃣ स्लोभेनिया\n• ट्रक चालक\n• वेल्डर\n• EU पहुँच र लाभहरू\n• ✅ खाडी उम्मेदवार मात्र\n\n2️⃣ माल्टा\n• आतिथ्य पेशेवरहरू\n• व्यापार पेशाहरू\n• अपरेटरहरू\n• ✅ खाडी उम्मेदवार मात्र\n\n3️⃣ क्रोएशिया\n• आतिथ्य पेशेवरहरू\n• व्यापार पेशाहरू\n• अपरेटरहरू\n• ✅ खाडी उम्मेदवार मात्र\n\n📱 व्हाट्सएप CV: +971 50 181 8023",
    fil: "🇪🇺 EUROPEAN WORK PERMITS (Gulf Candidates Lamang)\n\n1️⃣ SLOVENIA\n• Truck Drivers (Cat C/CE license, 2+ years)\n• Welders (TIG/MIG certified, 3+ years)\n• Benefits: EU wages, accommodation\n• Interview: English (video call)\n• ✅ Gulf Candidates Lamang\n\n2️⃣ MALTA\n• Hospitality (2+ years)\n• Trade Professions (3+ years)\n• Operators (certified, 2+ years)\n• Interview: English (required)\n• ✅ Gulf Candidates Lamang\n\n3️⃣ CROATIA\n• Hospitality (tourism, 2+ years)\n• Trade Professions (construction, 3+ years)\n• Operators (2+ years)\n• Interview: English required\n• ✅ Gulf Candidates Lamang\n\n📱 WhatsApp CV: +971 50 181 8023"
  },
  germany: {
    en: "🇩🇪 GERMANY SKILLED WORKER PROGRAM\n✅ Open to All Nationalities\n\n1️⃣ EU BLUE CARD\n• University degree required\n• Salary: €45,300+ (€41,042 for IT/healthcare)\n• Permanent residence: 21-33 months\n• Family visa: Immediate\n• Spouse work: Unrestricted\n\n2️⃣ SKILLED WORKER VISA\n• Vocational/university qualification\n• Job offer from German employer\n• Language: German B1 or English (IT roles)\n• Recognition certificate required\n\n💼 In-Demand:\n• IT professionals & software engineers\n• Engineers (mechanical, electrical, civil)\n• Healthcare (nurses, doctors)\n• Skilled trades\n\n📋 Process:\n1. Qualification recognition\n2. Job search support\n3. Employment contract\n4. Visa application\n5. Interview (English/German)\n6. Visa approval & relocation\n\n📱 WhatsApp: +971 50 181 8023",
    hi: "🇩🇪 जर्मनी स्किल्ड वर्कर प्रोग्राम\n✅ सभी राष्ट्रीयताओं के लिए खुला\n\n1️⃣ EU ब्लू कार्ड\n• विश्वविद्यालय डिग्री आवश्यक\n• वेतन: €45,300+ (IT/स्वास्थ्य के लिए €41,042)\n• स्थायी निवास: 21-33 महीने\n• परिवार वीजा: तत्काल\n• जीवनसाथी काम: प्रतिबंधित नहीं\n\n2️⃣ स्किल्ड वर्कर वीजा\n• व्यावसायिक/विश्वविद्यालय योग्यता\n• जर्मन नियोक्ता से नौकरी की पेशकश\n• भाषा: जर्मन B1 या अंग्रेजी (IT)\n• मान्यता प्रमाणपत्र आवश्यक\n\n💼 मांग में:\n• IT पेशेवर और सॉफ्टवेयर इंजीनियर\n• इंजीनियर (यांत्रिक, विद्युत, सिविल)\n• स्वास्थ्य सेवा (नर्स, डॉक्टर)\n• कुशल ट्रेड\n\n📋 प्रक्रिया:\n1. योग्यता मान्यता\n2. नौकरी खोज सहायता\n3. रोजगार अनुबंध\n4. वीजा आवेदन\n5. साक्षात्कार (अंग्रेजी/जर्मन)\n6. वीजा स्वीकृति और स्थानांतरण\n\n📱 व्हाट्सएप: +971 50 181 8023",
    pa: "🇩🇪 ਜਰਮਨੀ ਸਕਿੱਲਡ ਵਰਕਰ ਪ੍ਰੋਗਰਾਮ\n✅ ਸਾਰੀਆਂ ਰਾਸ਼ਟਰੀਅਤਾਵਾਂ ਲਈ ਖੁੱਲ੍ਹਾ\n\n1️⃣ EU ਬਲੂ ਕਾਰਡ\n• ਯੂਨੀਵਰਸਿਟੀ ਡਿਗਰੀ ਲੋੜੀਂਦੀ\n• ਤਨਖਾਹ: €45,300+ (IT/ਸਿਹਤ ਲਈ €41,042)\n• ਸਥਾਈ ਨਿਵਾਸ: 21-33 ਮਹੀਨੇ\n• ਪਰਿਵਾਰ ਵੀਜ਼ਾ: ਤੁਰੰਤ\n• ਜੀਵਨ ਸਾਥੀ ਕੰਮ: ਬਿਨਾਂ ਪਾਬੰਦੀ\n\n2️⃣ ਸਕਿੱਲਡ ਵਰਕਰ ਵੀਜ਼ਾ\n• ਵੋਕੇਸ਼ਨਲ/ਯੂਨੀਵਰਸਿਟੀ ਯੋਗਤਾ\n• ਜਰਮਨ ਰੁਜ਼ਗਾਰਦਾਤਾ ਤੋਂ ਨੌਕਰੀ\n• ਭਾਸ਼ਾ: ਜਰਮਨ B1 ਜਾਂ ਅੰਗਰੇਜ਼ੀ (IT)\n• ਮਾਨਤਾ ਸਰਟੀਫਿਕੇਟ ਲੋੜੀਂਦਾ\n\n💼 ਮੰਗ ਵਿੱਚ:\n• IT ਪੇਸ਼ੇਵਰ ਅਤੇ ਸੌਫਟਵੇਅਰ ਇੰਜੀਨੀਅਰ\n• ਇੰਜੀਨੀਅਰ (ਮਕੈਨੀਕਲ, ਇਲੈਕਟ੍ਰੀਕਲ, ਸਿਵਲ)\n• ਸਿਹਤ ਸੰਭਾਲ (ਨਰਸ, ਡਾਕਟਰ)\n• ਹੁਨਰਮੰਦ ਟਰੇਡ\n\n📱 ਵਟਸਐਪ: +971 50 181 8023",
    ne: "🇩🇪 जर्मनी स्किल्ड वर्कर कार्यक्रम\n✅ सबै राष्ट्रियताका लागि खुला\n\n1️⃣ EU ब्लू कार्ड\n• विश्वविद्यालय डिग्री आवश्यक\n• तलब: €45,300+ (IT/स्वास्थ्यको लागि €41,042)\n• स्थायी निवास: 21-33 महिना\n• परिवार भिसा: तुरुन्तै\n• जीवनसाथी काम: असीमित\n\n2️⃣ स्किल्ड वर्कर भिसा\n• व्यावसायिक/विश्वविद्यालय योग्यता\n• जर्मन नियोक्ताबाट काम प्रस्ताव\n• भाषा: जर्मन B1 वा अंग्रेजी (IT)\n• मान्यता प्रमाणपत्र आवश्यक\n\n💼 मागमा:\n• IT पेशेवर र सफ्टवेयर इन्जिनियर\n• इन्जिनियर (मेकानिकल, विद्युतीय, सिभिल)\n• स्वास्थ्य सेवा (नर्स, डाक्टर)\n• दक्ष ट्रेड\n\n📱 व्हाट्सएप: +971 50 181 8023",
    fil: "🇩🇪 GERMANY SKILLED WORKER PROGRAM\n✅ Bukas sa Lahat ng Nationality\n\n1️⃣ EU BLUE CARD\n• University degree required\n• Sahod: €45,300+ (€41,042 para sa IT/healthcare)\n• Permanent residence: 21-33 buwan\n• Family visa: Kaagad\n• Asawa pwedeng magtrabaho: Walang limit\n\n2️⃣ SKILLED WORKER VISA\n• Vocational/university qualification\n• Job offer from German employer\n• Wika: German B1 o English (IT roles)\n• Recognition certificate needed\n\n💼 In-Demand:\n• IT professionals & software engineers\n• Engineers (mechanical, electrical, civil)\n• Healthcare (nurses, doctors)\n• Skilled trades\n\n📱 WhatsApp: +971 50 181 8023"
  },
  study: {
    en: "🎓 STUDY VISA PROGRAMS\n\n1️⃣ CANADA\n• 900,000+ permits issued\n• Post-Graduation Work Permit (PGWP)\n• Pathway to PR via Express Entry\n• Popular: Business, IT, Healthcare\n• Partner work rights\n\n2️⃣ AUSTRALIA\n• Work 48 hours/fortnight\n• Graduate visa (Subclass 485): 2-4 years\n• Partner can work full-time\n• Fees: Competitive rates\n\n3️⃣ UK & GERMANY\n• Quality education\n• Part-time work allowed\n• Post-study work opportunities\n\n💡 Benefits:\n✓ Education to PR pathway\n✓ Work while studying\n✓ Family sponsorship options\n\n📱 WhatsApp CV: +971 50 181 8023",
    hi: "🎓 स्टडी वीजा कार्यक्रम\n\n1️⃣ कनाडा\n• 900,000+ परमिट जारी\n• पोस्ट-ग्रेजुएशन वर्क परमिट (PGWP)\n• एक्सप्रेस एंट्री के माध्यम से PR का रास्ता\n• लोकप्रिय: बिजनेस, IT, हेल्थकेयर\n• साथी कार्य अधिकार\n\n2️⃣ ऑस्ट्रेलिया\n• 48 घंटे/पखवाड़े काम करें\n• ग्रेजुएट वीजा (सबक्लास 485): 2-4 वर्ष\n• साथी पूर्णकालिक काम कर सकता है\n• शुल्क: प्रतिस्पर्धी दरें\n\n3️⃣ UK और जर्मनी\n• गुणवत्ता शिक्षा\n• पार्ट-टाइम काम की अनुमति\n• अध्ययन के बाद काम के अवसर\n\n💡 लाभ:\n✓ शिक्षा से PR का रास्ता\n✓ पढ़ाई के दौरान काम\n✓ पारिवारिक प्रायोजन विकल्प\n\n📱 व्हाट्सएप CV: +971 50 181 8023",
    pa: "🎓 ਸਟੱਡੀ ਵੀਜ਼ਾ ਪ੍ਰੋਗਰਾਮ\n\n1️⃣ ਕੈਨੇਡਾ\n• 900,000+ ਪਰਮਿਟ ਜਾਰੀ\n• ਪੋਸਟ-ਗ੍ਰੈਜੂਏਸ਼ਨ ਵਰਕ ਪਰਮਿਟ (PGWP)\n• ਐਕਸਪ੍ਰੈਸ ਐਂਟਰੀ ਰਾਹੀਂ PR ਦਾ ਰਸਤਾ\n• ਪ੍ਰਸਿੱਧ: ਬਿਜ਼ਨਸ, IT, ਸਿਹਤ ਸੰਭਾਲ\n• ਸਾਥੀ ਕੰਮ ਦੇ ਅਧਿਕਾਰ\n\n2️⃣ ਆਸਟ੍ਰੇਲੀਆ\n• 48 ਘੰਟੇ/ਪੰਦਰਵਾੜਾ ਕੰਮ\n• ਗ੍ਰੈਜੂਏਟ ਵੀਜ਼ਾ (ਸਬਕਲਾਸ 485): 2-4 ਸਾਲ\n• ਸਾਥੀ ਫੁੱਲ-ਟਾਈਮ ਕੰਮ ਕਰ ਸਕਦਾ ਹੈ\n• ਫੀਸ: ਮੁਕਾਬਲੇਬਾਜ਼ ਦਰਾਂ\n\n3️⃣ UK ਅਤੇ ਜਰਮਨੀ\n• ਗੁਣਵੱਤਾ ਸਿੱਖਿਆ\n• ਪਾਰਟ-ਟਾਈਮ ਕੰਮ ਦੀ ਇਜਾਜ਼ਤ\n• ਪੜ੍ਹਾਈ ਬਾਅਦ ਕੰਮ ਦੇ ਮੌਕੇ\n\n💡 ਫਾਇਦੇ:\n✓ ਸਿੱਖਿਆ ਤੋਂ PR ਦਾ ਰਸਤਾ\n✓ ਪੜ੍ਹਾਈ ਦੌਰਾਨ ਕੰਮ\n✓ ਪਰਿਵਾਰਕ ਸਪਾਂਸਰਸ਼ਿਪ ਵਿਕਲਪ\n\n📱 ਵਟਸਐਪ CV: +971 50 181 8023",
    ne: "🎓 अध्ययन भिसा कार्यक्रमहरू\n\n1️⃣ क्यानाडा\n• 900,000+ अनुमति जारी\n• स्नातकोत्तर कार्य अनुमति (PGWP)\n• एक्सप्रेस एन्ट्री मार्फत PR को बाटो\n• लोकप्रिय: व्यापार, IT, स्वास्थ्य सेवा\n• साथी कार्य अधिकार\n\n2️⃣ अष्ट्रेलिया\n• 48 घण्टा/पन्ध्र दिन काम\n• स्नातक भिसा (सबक्लास 485): 2-4 वर्ष\n• साथी पूर्ण-समय काम गर्न सक्छ\n• शुल्क: प्रतिस्पर्धी दरहरू\n\n3️⃣ UK र जर्मनी\n• गुणस्तरीय शिक्षा\n• अंशकालिक काम अनुमति\n• अध्ययन पछि कामको अवसरहरू\n\n💡 फाइदाहरू:\n✓ शिक्षाबाट PR को बाटो\n✓ अध्ययन गर्दा काम\n✓ पारिवारिक प्रायोजन विकल्पहरू\n\n📱 व्हाट्सएप CV: +971 50 181 8023",
    fil: "🎓 STUDY VISA PROGRAMS\n\n1️⃣ CANADA\n• 900,000+ permits issued\n• Post-Graduation Work Permit (PGWP)\n• Pathway sa PR via Express Entry\n• Popular: Business, IT, Healthcare\n• May partner work rights\n\n2️⃣ AUSTRALIA\n• Work 48 hours/fortnight\n• Graduate visa (Subclass 485): 2-4 taon\n• Partner pwedeng full-time work\n• Fees: Competitive rates\n\n3️⃣ UK & GERMANY\n• Quality education\n• Part-time work allowed\n• Post-study work opportunities\n\n💡 Benefits:\n✓ Education to PR pathway\n✓ Magtrabaho habang nag-aaral\n✓ Family sponsorship options\n\n📱 WhatsApp CV: +971 50 181 8023"
  },
  news: {
    en: "📰 LATEST IMMIGRATION NEWS\n\n🇨🇦 CANADA\n• 3,700 ITAs at CRS 536 (Oct 28)\n• Provincial nominations at record high\n• Atlantic Immigration: Lower requirements\n• Study permits lead to PR pathways\n\n🇦🇺 AUSTRALIA\n• Priority occupations list updated\n• 190,000 skilled visas in 2025-26\n• Regional visa (491): Great PR pathway\n• Student visa GTE simplified\n\n🇪🇺 EUROPE\n• Germany Blue Card opportunities\n• Malta Nomad permits up 45%\n• Croatia IT fast-track program\n• Slovenia blue collar expansion\n\n📱 Get detailed news updates: +971 50 181 8023",
    hi: "📰 नवीनतम इमिग्रेशन समाचार\n\n🇨🇦 कनाडा\n• CRS 536 पर 3,700 ITA (28 अक्टूबर)\n• प्रांतीय नामांकन रिकॉर्ड उच्च पर\n• अटलांटिक इमिग्रेशन: कम आवश्यकताएं\n• स्टडी परमिट PR रास्ते की ओर ले जाते हैं\n\n🇦🇺 ऑस्ट्रेलिया\n• प्राथमिकता व्यवसाय सूची अपडेट\n• 2025-26 में 190,000 स्किल्ड वीजा\n• क्षेत्रीय वीजा (491): बेहतरीन PR रास्ता\n• स्टूडेंट वीजा GTE सरल बनाया\n\n🇪🇺 यूरोप\n• जर्मनी ब्लू कार्ड अवसर\n• माल्टा नोमैड परमिट 45% बढ़े\n• क्रोएशिया IT फास्ट-ट्रैक कार्यक्रम\n• स्लोवेनिया ब्लू कॉलर विस्तार\n\n📱 विस्तृत समाचार अपडेट: +971 50 181 8023",
    pa: "📰 ਨਵੀਨਤਮ ਇਮੀਗ੍ਰੇਸ਼ਨ ਖ਼ਬਰਾਂ\n\n🇨🇦 ਕੈਨੇਡਾ\n• CRS 536 'ਤੇ 3,700 ITA (28 ਅਕਤੂਬਰ)\n• ਪ੍ਰੋਵਿੰਸ਼ੀਅਲ ਨਾਮਜ਼ਦਗੀਆਂ ਰਿਕਾਰਡ ਉੱਚੀਆਂ\n• ਐਟਲਾਂਟਿਕ ਇਮੀਗ੍ਰੇਸ਼ਨ: ਘੱਟ ਲੋੜਾਂ\n• ਸਟੱਡੀ ਪਰਮਿਟ PR ਰਸਤੇ ਵੱਲ ਲੈ ਜਾਂਦੇ ਹਨ\n\n🇦🇺 ਆਸਟ੍ਰੇਲੀਆ\n• ਤਰਜੀਹੀ ਪੇਸ਼ਿਆਂ ਦੀ ਸੂਚੀ ਅੱਪਡੇਟ\n• 2025-26 ਵਿੱਚ 190,000 ਸਕਿੱਲਡ ਵੀਜ਼ਾ\n• ਖੇਤਰੀ ਵੀਜ਼ਾ (491): ਸ਼ਾਨਦਾਰ PR ਰਸਤਾ\n• ਸਟੂਡੈਂਟ ਵੀਜ਼ਾ GTE ਸਰਲ ਬਣਾਇਆ\n\n🇪🇺 ਯੂਰਪ\n• ਜਰਮਨੀ ਬਲੂ ਕਾਰਡ ਮੌਕੇ\n• ਮਾਲਟਾ ਨੋਮੈਡ ਪਰਮਿਟ 45% ਵੱਧੇ\n• ਕ੍ਰੋਏਸ਼ੀਆ IT ਫਾਸਟ-ਟਰੈਕ ਪ੍ਰੋਗਰਾਮ\n• ਸਲੋਵੇਨੀਆ ਬਲੂ ਕਾਲਰ ਵਿਸਤਾਰ\n\n📱 ਵਿਸਤ੍ਰਿਤ ਖ਼ਬਰ ਅੱਪਡੇਟ: +971 50 181 8023",
    ne: "📰 नवीनतम अध्यागमन समाचार\n\n🇨🇦 क्यानाडा\n• CRS 536 मा 3,700 ITA (अक्टोबर 28)\n• प्रान्तीय मनोनयन रेकर्ड उच्च\n• एट्लान्टिक अध्यागमन: कम आवश्यकताहरू\n• अध्ययन अनुमति PR मार्गहरू तर्फ\n\n🇦🇺 अष्ट्रेलिया\n• प्राथमिकता पेशा सूची अद्यावधिक\n• 2025-26 मा 190,000 दक्ष भिसा\n• क्षेत्रीय भिसा (491): उत्कृष्ट PR मार्ग\n• विद्यार्थी भिसा GTE सरलीकृत\n\n🇪🇺 युरोप\n• जर्मनी ब्लू कार्ड अवसरहरू\n• माल्टा नोमाड अनुमति 45% बढ्यो\n• क्रोएशिया IT फास्ट-ट्र्याक कार्यक्रम\n• स्लोभेनिया ब्लू कलर विस्तार\n\n📱 विस्तृत समाचार अपडेट: +971 50 181 8023",
    fil: "📰 LATEST IMMIGRATION NEWS\n\n🇨🇦 CANADA\n• 3,700 ITAs sa CRS 536 (Oct 28)\n• Provincial nominations sa record high\n• Atlantic Immigration: Mas mababang requirements\n• Study permits to PR pathways\n\n🇦🇺 AUSTRALIA\n• Priority occupations list updated\n• 190,000 skilled visas sa 2025-26\n• Regional visa (491): Magandang PR pathway\n• Student visa GTE simplified\n\n🇪🇺 EUROPE\n• Germany Blue Card opportunities\n• Malta Nomad permits up 45%\n• Croatia IT fast-track program\n• Slovenia blue collar expansion\n\n📱 Get detailed news updates: +971 50 181 8023"
  }
};

const knowledgeBase = {
  greetings: ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening', 'greetings', 'namaste', 'namaskar', 'sat sri akal', 'kumusta', 'नमस्ते', 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ'],
  services: ['service', 'what do you do', 'what do you offer', 'help with', 'can you help', 'tell me more', 'सेवा', 'ਸੇਵਾ', 'सेवाहरू', 'serbisyo'],
  contact: ['contact', 'phone', 'email', 'whatsapp', 'call', 'reach', 'office', 'संपर्क', 'ਸੰਪਰਕ', 'सम्पर्क', 'kontak'],
  canada: ['canada', 'canadian', 'express entry', 'pnp', 'provincial', 'कनाडा', 'ਕੈਨੇਡਾ', 'क्यानाडा'],
  australia: ['australia', 'australian', '189', '190', '491', 'skilled', 'ऑस्ट्रेलिया', 'ਆਸਟ੍ਰੇਲੀਆ', 'अष्ट्रेलिया'],
  europe: ['europe', 'european', 'slovenia', 'malta', 'croatia', 'blue collar', 'truck driver', 'welder', 'hospitality', 'यूरोप', 'ਯੂਰਪ', 'युरोप'],
  germany: ['germany', 'german', 'blue card', 'skilled worker', 'eu blue card', 'जर्मनी', 'ਜਰਮਨੀ', 'जर्मनी'],
  study: ['study', 'student', 'visa', 'education', 'college', 'university', 'स्टडी', 'अध्ययन', 'ਸਟੱਡੀ', 'pag-aaral'],
  news: ['news', 'update', 'latest', 'information', 'समाचार', 'खबर', 'ਖ਼ਬਰ', 'balita']
};

function getResponse(userMessage: string, language: Language): { text: string; suggestions?: string[] } {
  const message = userMessage.toLowerCase();
  
  // Greetings
  if (knowledgeBase.greetings.some(greeting => message.includes(greeting))) {
    return {
      text: translations.greeting[language],
      suggestions: language === 'en' 
        ? ["Tell me about your services", "Contact information", "Canada programs", "Australia programs"]
        : language === 'hi'
        ? ["अपनी सेवाओं के बारे में बताएं", "संपर्क जानकारी", "कनाडा कार्यक्रम", "ऑस्ट्रेलिया कार्यक्रम"]
        : language === 'pa'
        ? ["ਆਪਣੀਆਂ ਸੇਵਾਵਾਂ ਬਾਰੇ ਦੱਸੋ", "ਸੰਪਰਕ ਜਾਣਕਾਰੀ", "ਕੈਨੇਡਾ ਪ੍ਰੋਗਰਾਮ", "ਆਸਟ੍ਰੇਲੀਆ ਪ੍ਰੋਗਰਾਮ"]
        : language === 'ne'
        ? ["आफ्नो सेवाहरूको बारेमा बताउनुहोस्", "सम्पर्क जानकारी", "क्यानाडा कार्यक्रमहरू", "अष्ट्रेलिया कार्यक्रमहरू"]
        : ["Sabihin mo ang tungkol sa inyong serbisyo", "Impormasyon sa pakikipag-ugnayan", "Canada programs", "Australia programs"]
    };
  }
  
  // Canada specific
  if (knowledgeBase.canada.some(keyword => message.includes(keyword))) {
    return {
      text: translations.canada[language],
      suggestions: language === 'en'
        ? ["Australia programs", "Study visas", "Europe work permits", "Contact us"]
        : language === 'hi'
        ? ["ऑस्ट्रेलिया कार्यक्रम", "स्टडी वीजा", "यूरोप वर्क परमिट", "हमसे संपर्क करें"]
        : language === 'pa'
        ? ["ਆਸਟ੍ਰੇਲੀਆ ਪ੍ਰੋਗਰਾਮ", "ਸਟੱਡੀ ਵੀਜ਼ਾ", "ਯੂਰਪ ਵਰਕ ਪਰਮਿਟ", "ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ"]
        : language === 'ne'
        ? ["अष्ट्रेलिया कार्यक्रमहरू", "अध्ययन भिसा", "युरोप कार्य अनुमति", "हामीलाई सम्पर्क गर्नुहोस्"]
        : ["Australia programs", "Study visas", "Europe work permits", "Kontakin kami"]
    };
  }
  
  // Australia specific
  if (knowledgeBase.australia.some(keyword => message.includes(keyword))) {
    return {
      text: translations.australia[language],
      suggestions: language === 'en'
        ? ["Canada programs", "Study visas", "Europe work permits", "Contact us"]
        : language === 'hi'
        ? ["कनाडा कार्यक्रम", "स्टडी वीजा", "यूरोप वर्क परमिट", "हमसे संपर्क करें"]
        : language === 'pa'
        ? ["ਕੈਨੇਡਾ ਪ੍ਰੋਗਰਾਮ", "ਸਟੱਡੀ ਵੀਜ਼ਾ", "ਯੂਰਪ ਵਰਕ ਪਰਮਿਟ", "ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ"]
        : language === 'ne'
        ? ["क्यानाडा कार्यक्रमहरू", "अध्ययन भिसा", "युरोप कार्य अनुमति", "हामीलाई सम्पर्क गर्नुहोस्"]
        : ["Canada programs", "Study visas", "Europe work permits", "Kontakin kami"]
    };
  }
  
  // Europe specific (Gulf only)
  if (knowledgeBase.europe.some(keyword => message.includes(keyword))) {
    return {
      text: translations.europe[language],
      suggestions: language === 'en'
        ? ["Slovenia details", "Malta details", "Croatia details", "Germany program"]
        : language === 'hi'
        ? ["स्लोवेनिया विवरण", "माल्टा विवरण", "क्रोएशिया विवरण", "जर्मनी कार्यक्रम"]
        : language === 'pa'
        ? ["ਸਲੋਵੇਨੀਆ ਵੇਰਵੇ", "ਮਾਲਟਾ ਵੇਰਵੇ", "ਕ੍ਰੋਏਸ਼ੀਆ ਵੇਰਵੇ", "ਜਰਮਨੀ ਪ੍ਰੋਗਰਾਮ"]
        : language === 'ne'
        ? ["स्लोभेनिया विवरण", "माल्टा विवरण", "क्रोएशिया विवरण", "जर्मनी कार्यक्रम"]
        : ["Slovenia details", "Malta details", "Croatia details", "Germany program"]
    };
  }
  
  // Germany Skilled Worker Program
  if (knowledgeBase.germany.some(keyword => message.includes(keyword))) {
    return {
      text: translations.germany[language],
      suggestions: language === 'en'
        ? ["EU Blue Card", "Skilled Worker Visa", "Study visas", "Contact us"]
        : language === 'hi'
        ? ["EU ब्लू कार्ड", "स्किल्ड वर्कर वीजा", "स्टडी वीजा", "हमसे संपर्क करें"]
        : language === 'pa'
        ? ["EU ਬਲੂ ਕਾਰਡ", "ਸਕਿੱਲਡ ਵਰਕਰ ਵੀਜ਼ਾ", "ਸਟੱਡੀ ਵੀਜ਼ਾ", "ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ"]
        : language === 'ne'
        ? ["EU ब्लू कार्ड", "स्किल्ड वर्कर भिसा", "अध्ययन भिसा", "हामीलाई सम्पर्क गर्नुहोस्"]
        : ["EU Blue Card", "Skilled Worker Visa", "Study visas", "Kontakin kami"]
    };
  }
  
  // Study visas
  if (knowledgeBase.study.some(keyword => message.includes(keyword))) {
    return {
      text: translations.study[language],
      suggestions: language === 'en'
        ? ["Canada PR programs", "Australia PR programs", "Contact us", "Latest news"]
        : language === 'hi'
        ? ["कनाडा PR कार्यक्रम", "ऑस्ट्रेलिया PR कार्यक्रम", "हमसे संपर्क करें", "नवीनतम समाचार"]
        : language === 'pa'
        ? ["ਕੈਨੇਡਾ PR ਪ੍ਰੋਗਰਾਮ", "ਆਸਟ੍ਰੇਲੀਆ PR ਪ੍ਰੋਗਰਾਮ", "ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ", "ਨਵੀਨਤਮ ਖ਼ਬਰਾਂ"]
        : language === 'ne'
        ? ["क्यानाडा PR कार्यक्रमहरू", "अष्ट्रेलिया PR कार्यक्रमहरू", "हामीलाई सम्पर्क गर्नुहोस्", "नवीनतम समाचार"]
        : ["Canada PR programs", "Australia PR programs", "Kontakin kami", "Latest news"]
    };
  }
  
  // News
  if (knowledgeBase.news.some(keyword => message.includes(keyword))) {
    return {
      text: translations.news[language],
      suggestions: language === 'en'
        ? ["Canada programs", "Australia programs", "Europe permits", "Contact us"]
        : language === 'hi'
        ? ["कनाडा कार्यक्रम", "ऑस्ट्रेलिया कार्यक्रम", "यूरोप परमिट", "हमसे संपर्क करें"]
        : language === 'pa'
        ? ["ਕੈਨੇਡਾ ਪ੍ਰੋਗਰਾਮ", "ਆਸਟ੍ਰੇਲੀਆ ਪ੍ਰੋਗਰਾਮ", "ਯੂਰਪ ਪਰਮਿਟ", "ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ"]
        : language === 'ne'
        ? ["क्यानाडा कार्यक्रमहरू", "अष्ट्रेलिया कार्यक्रमहरू", "युरोप अनुमति", "हामीलाई सम्पर्क गर्नुहोस्"]
        : ["Canada programs", "Australia programs", "Europe permits", "Kontakin kami"]
    };
  }
  
  // Services
  if (knowledgeBase.services.some(keyword => message.includes(keyword))) {
    return {
      text: translations.services[language],
      suggestions: language === 'en'
        ? ["Canada programs", "Australia programs", "Study visas", "Contact us"]
        : language === 'hi'
        ? ["कनाडा कार्यक्रम", "ऑस्ट्रेलिया कार्यक्रम", "स्टडी वीजा", "हमसे संपर्क करें"]
        : language === 'pa'
        ? ["ਕੈਨੇਡਾ ਪ੍ਰੋਗਰਾਮ", "ਆਸਟ੍ਰੇਲੀਆ ਪ੍ਰੋਗਰਾਮ", "ਸਟੱਡੀ ਵੀਜ਼ਾ", "ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ"]
        : language === 'ne'
        ? ["क्यानाडा कार्यक्रमहरू", "अष्ट्रेलिया कार्यक्रमहरू", "अध्ययन भिसा", "हामीलाई सम्पर्क गर्नुहोस्"]
        : ["Canada programs", "Australia programs", "Study visas", "Kontakin kami"]
    };
  }
  
  // Contact
  if (knowledgeBase.contact.some(keyword => message.includes(keyword))) {
    return {
      text: translations.contact[language],
      suggestions: language === 'en'
        ? ["WhatsApp Dubai", "WhatsApp India", "Book consultation", "Ask another question"]
        : language === 'hi'
        ? ["व्हाट्सएप दुबई", "व्हाट्सएप भारत", "परामर्श बुक करें", "दूसरा प्रश्न पूछें"]
        : language === 'pa'
        ? ["ਵਟਸਐਪ ਦੁਬਈ", "ਵਟਸਐਪ ਭਾਰਤ", "ਸਲਾਹ ਬੁੱਕ ਕਰੋ", "ਹੋਰ ਸਵਾਲ ਪੁੱਛੋ"]
        : language === 'ne'
        ? ["व्हाट्सएप दुबई", "व्हाट्सएप भारत", "परामर्श बुक गर्नुहोस्", "अर्को प्रश्न सोध्नुहोस्"]
        : ["WhatsApp Dubai", "WhatsApp India", "Mag-book ng konsultasyon", "Magtanong ng iba"]
    };
  }
  
  // Default response
  return {
    text: language === 'en' 
      ? "I'd be happy to help you! JioWW Global specializes in immigration and study visa services for Canada, Australia, and Europe. You can ask me about:\n\n• Canada PR programs\n• Australia PR programs\n• European work permits\n• Study visas\n• Latest immigration news\n• Contact information\n\nWhat would you like to know?"
      : language === 'hi'
      ? "मैं आपकी मदद करने में खुश हूं! JioWW Global कनाडा, ऑस्ट्रेलिया और यूरोप के लिए इमिग्रेशन और स्टडी वीजा सेवाओं में विशेषज्ञ है। आप मुझसे इसके बारे में पूछ सकते हैं:\n\n• कनाडा PR कार्यक्रम\n• ऑस्ट्रेलिया PR कार्यक्रम\n• यूरोपीय वर्क परमिट\n• स्टडी वीजा\n• नवीनतम इमिग्रेशन समाचार\n• संपर्क जानकारी\n\nआप क्या जानना चाहेंगे?"
      : language === 'pa'
      ? "ਮੈਂ ਤੁਹਾਡੀ ਮਦਦ ਕਰਨ ਵਿੱਚ ਖੁਸ਼ ਹਾਂ! JioWW Global ਕੈਨੇਡਾ, ਆਸਟ੍ਰੇਲੀਆ ਅਤੇ ਯੂਰਪ ਲਈ ਇਮੀਗ੍ਰੇਸ਼ਨ ਅਤੇ ਸਟੱਡੀ ਵੀਜ਼ਾ ਸੇਵਾਵਾਂ ਵਿੱਚ ਮਾਹਰ ਹੈ। ਤੁਸੀਂ ਮੈਨੂੰ ਇਸ ਬਾਰੇ ਪੁੱਛ ਸਕਦੇ ਹੋ:\n\n• ਕੈਨੇਡਾ PR ਪ੍ਰੋਗਰਾਮ\n• ਆਸਟ੍ਰੇਲੀਆ PR ਪ੍ਰੋਗਰਾਮ\n• ਯੂਰਪੀਅਨ ਵਰਕ ਪਰਮਿਟ\n• ਸਟੱਡੀ ਵੀਜ਼ਾ\n• ਨਵੀਨਤਮ ਇਮੀਗ੍ਰੇਸ਼ਨ ਖ਼ਬਰਾਂ\n• ਸੰਪਰਕ ਜਾਣਕਾਰੀ\n\nਤੁਸੀਂ ਕੀ ਜਾਣਨਾ ਚਾਹੋਗੇ?"
      : language === 'ne'
      ? "म तपाईंलाई मद्दत गर्न खुसी छु! JioWW Global क्यानाडा, अष्ट्रेलिया र युरोपका लागि अध्यागमन र अध्ययन भिसा सेवाहरूमा विशेषज्ञ छ। तपाईं मलाई यसको बारेमा सोध्न सक्नुहुन्छ:\n\n• क्यानाडा PR कार्यक्रमहरू\n• अष्ट्रेलिया PR कार्यक्रमहरू\n• युरोपेली कार्य अनुमतिहरू\n• अध्ययन भिसा\n• नवीनतम अध्यागमन समाचार\n• सम्पर्क जानकारी\n\nतपाईं के जान्न चाहनुहुन्छ?"
      : "Masaya akong tumulong sa inyo! Ang JioWW Global ay espesyalista sa immigration at study visa services para sa Canada, Australia, at Europe. Pwede ninyong itanong sa akin ang tungkol sa:\n\n• Canada PR programs\n• Australia PR programs\n• European work permits\n• Study visas\n• Latest immigration news\n• Contact information\n\nAno ang gusto ninyong malaman?",
    suggestions: language === 'en'
      ? ["Services", "Contact", "Canada", "Australia"]
      : language === 'hi'
      ? ["सेवाएं", "संपर्क", "कनाडा", "ऑस्ट्रेलिया"]
      : language === 'pa'
      ? ["ਸੇਵਾਵਾਂ", "ਸੰਪਰਕ", "ਕੈਨੇਡਾ", "ਆਸਟ੍ਰੇਲੀਆ"]
      : language === 'ne'
      ? ["सेवाहरू", "सम्पर्क", "क्यानाडा", "अष्ट्रेलिया"]
      : ["Serbisyo", "Kontak", "Canada", "Australia"]
  };
}

export function AIChatbot({ isOpen: externalIsOpen, onOpenChange, initialMessage }: AIChatbotProps = {}) {
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  const [language, setLanguage] = useState<Language>('en');
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);

  const isOpen = externalIsOpen !== undefined ? externalIsOpen : internalIsOpen;
  const setIsOpen = onOpenChange || setInternalIsOpen;

  // Initialize welcome message
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{
        id: '1',
        text: translations.greeting[language],
        sender: 'bot',
        timestamp: new Date(),
        suggestions: language === 'en'
          ? ["📱 Send CV via WhatsApp", "✉️ Send CV via Email", "Tell me about services", "Contact information"]
          : language === 'hi'
          ? ["📱 व्हाट्सएप से CV भेजें", "✉️ ईमेल से CV भेजें", "सेवाओं के बारे में", "संपर्क जानकारी"]
          : language === 'pa'
          ? ["📱 ਵਟਸਐਪ ਤੋਂ CV ਭੇਜੋ", "✉️ ਈਮੇਲ ਤੋਂ CV ਭੇਜੋ", "ਸੇਵਾਵਾਂ ਬਾਰੇ", "ਸੰਪਰਕ ਜਾਣਕਾਰੀ"]
          : language === 'ne'
          ? ["📱 व्हाट्सएप बाट CV", "✉️ इमेल बाट CV", "सेवाहरूको बारेमा", "सम्पर्क जानकारी"]
          : ["📱 I-WhatsApp ang CV", "✉️ I-Email ang CV", "Tungkol sa serbisyo", "Contact info"]
      }]);
    }
  }, [language]);

  // Update messages when language changes
  useEffect(() => {
    if (messages.length > 0) {
      // Update the welcome message when language changes
      const updatedMessages = messages.map((msg, index) => {
        if (index === 0 && msg.sender === 'bot') {
          return {
            ...msg,
            text: translations.greeting[language],
            suggestions: language === 'en'
              ? ["📱 Send CV via WhatsApp", "✉️ Send CV via Email", "Tell me about services", "Contact information"]
              : language === 'hi'
              ? ["📱 व्हाट्सएप से CV भेजें", "✉️ ईमेल से CV भेजें", "सेवाओं के बारे में", "संपर्क जानकारी"]
              : language === 'pa'
              ? ["📱 ਵਟਸਐਪ ਤੋਂ CV ਭੇਜੋ", "✉️ ਈਮੇਲ ਤੋਂ CV ਭੇਜੋ", "ਸੇਵਾਵਾਂ ਬਾਰੇ", "ਸੰਪਰਕ ਜਾਣਕਾਰੀ"]
              : language === 'ne'
              ? ["📱 व्हाट्सएप बाट CV", "✉️ इमेल बाट CV", "सेवाहरूको बारेमा", "सम्पर्क जानकारी"]
              : ["📱 I-WhatsApp ang CV", "✉️ I-Email ang CV", "Tungkol sa serbisyo", "Contact info"]
          };
        }
        return msg;
      });
      setMessages(updatedMessages);
    }
  }, [language]);

  // Handle initial message from external trigger
  useEffect(() => {
    if (initialMessage && isOpen && messages.length > 0) {
      handleSendMessage(initialMessage);
    }
  }, [initialMessage, isOpen]);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      
      // Set language for recognition
      const langCodes: Record<Language, string> = {
        en: 'en-US',
        hi: 'hi-IN',
        pa: 'pa-IN',
        ne: 'ne-NP',
        fil: 'fil-PH'
      };
      recognitionRef.current.lang = langCodes[language];

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, [language]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const speakText = (text: string) => {
    if (!voiceEnabled) return;
    
    window.speechSynthesis.cancel();
    synthRef.current = new SpeechSynthesisUtterance(text);
    
    const langCodes: Record<Language, string> = {
      en: 'en-US',
      hi: 'hi-IN',
      pa: 'pa-IN',
      ne: 'ne-NP',
      fil: 'fil-PH'
    };
    synthRef.current.lang = langCodes[language];
    synthRef.current.rate = 0.9;
    window.speechSynthesis.speak(synthRef.current);
  };

  const handleSendMessage = (messageText?: string) => {
    const text = messageText || inputValue.trim();
    if (!text) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    setTimeout(() => {
      const response = getResponse(text, language);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response.text,
        sender: 'bot',
        timestamp: new Date(),
        suggestions: response.suggestions
      };
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
      speakText(response.text);
    }, 1000 + Math.random() * 1000);
  };

  const toggleVoiceInput = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            className="fixed bottom-24 right-6 z-[55]"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Button
                onClick={() => setIsOpen(true)}
                className="h-14 w-14 rounded-full bg-gradient-to-r from-primary to-amber-400 text-black shadow-lg hover:shadow-primary/50 transition-all duration-300 relative"
              >
                <MessageCircle className="h-6 w-6" />
                <motion.div
                  className="absolute -top-1 -right-1 h-4 w-4 bg-green-500 rounded-full border-2 border-white"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </Button>
            </motion.div>
            <motion.div
              className="absolute -top-20 right-0 bg-gradient-to-r from-black/95 via-primary/20 to-black/95 backdrop-blur-sm border-2 border-primary/40 px-4 py-2.5 rounded-xl shadow-2xl"
              initial={{ opacity: 0, y: 10, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: 0.5, type: "spring", stiffness: 200 }}
            >
              <motion.div
                className="text-center"
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                <motion.p className="bg-gradient-to-r from-primary via-amber-400 to-primary bg-clip-text text-transparent font-bold text-base whitespace-nowrap">
                  Apply for Free
                </motion.p>
                <motion.p className="bg-gradient-to-r from-amber-400 via-primary to-amber-400 bg-clip-text text-transparent font-bold text-sm whitespace-nowrap">
                  Assessment / Interview
                </motion.p>
              </motion.div>
              <div className="absolute -bottom-2 right-8 w-4 h-4 bg-gradient-to-br from-black/95 to-primary/30 border-r-2 border-b-2 border-primary/40 transform rotate-45" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed bottom-6 right-6 z-[55] w-[400px] h-[600px] max-w-[calc(100vw-3rem)] max-h-[calc(100vh-3rem)]"
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="h-full bg-gradient-to-br from-black/95 to-gray-900/95 border-primary/30 shadow-2xl backdrop-blur-xl flex flex-col">
              {/* Header */}
              <CardHeader className="border-b border-primary/20 bg-gradient-to-r from-primary/10 to-amber-400/10 pb-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-r from-primary to-amber-400 flex items-center justify-center">
                        <Bot className="h-6 w-6 text-black" />
                      </div>
                      <motion.div
                        className="absolute -bottom-1 -right-1 h-3 w-3 bg-green-500 rounded-full border-2 border-black"
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />
                    </div>
                    <div>
                      <CardTitle className="text-white flex items-center space-x-2">
                        <span>JioWW AI Assistant</span>
                        <Sparkles className="h-4 w-4 text-primary" />
                      </CardTitle>
                      <p className="text-xs text-gray-400">Professional Immigration Consultant</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsOpen(false)}
                    className="text-gray-400 hover:text-white hover:bg-white/10"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>

                {/* Language Selector - Touch Buttons */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Languages className="h-3 w-3 text-primary" />
                    <span className="text-xs text-gray-400">Select Language:</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setVoiceEnabled(!voiceEnabled)}
                      className={`h-6 w-6 p-0 ml-auto ${voiceEnabled ? 'text-primary' : 'text-gray-400'}`}
                    >
                      {voiceEnabled ? <Volume2 className="h-3 w-3" /> : <VolumeX className="h-3 w-3" />}
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {Object.entries(languageNames).map(([code, name]) => (
                      <Button
                        key={code}
                        variant={language === code ? "default" : "outline"}
                        size="sm"
                        onClick={() => setLanguage(code as Language)}
                        className={`h-7 px-2 text-xs transition-all ${
                          language === code 
                            ? 'bg-gradient-to-r from-primary to-amber-400 text-black border-0 hover:from-amber-400 hover:to-primary' 
                            : 'bg-black/20 border-primary/20 text-gray-300 hover:bg-primary/10 hover:border-primary/40 hover:text-white'
                        }`}
                      >
                        <span className="mr-1">{languageFlags[code as Language]}</span>
                        {name}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              {/* Messages */}
              <CardContent className="flex-1 overflow-hidden p-0">
                <ScrollArea className="h-full px-4 py-4">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`flex items-start space-x-2 max-w-[85%] ${message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                          <div className={`h-7 w-7 rounded-full flex items-center justify-center flex-shrink-0 ${
                            message.sender === 'user' 
                              ? 'bg-primary/20' 
                              : 'bg-gradient-to-r from-primary/20 to-amber-400/20'
                          }`}>
                            {message.sender === 'user' ? (
                              <User className="h-4 w-4 text-primary" />
                            ) : (
                              <Bot className="h-4 w-4 text-primary" />
                            )}
                          </div>
                          <div>
                            <div className={`rounded-2xl px-3 py-2 text-sm ${
                              message.sender === 'user'
                                ? 'bg-gradient-to-r from-primary to-amber-400 text-black'
                                : 'bg-gray-800/80 text-white border border-primary/20'
                            }`}>
                              <p className="text-xs whitespace-pre-line leading-relaxed">{message.text}</p>
                            </div>
                            <p className="text-xs text-gray-500 mt-1 px-2">
                              {message.timestamp.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                            </p>
                            {message.suggestions && message.suggestions.length > 0 && (
                              <div className="mt-2 space-y-1">
                                {message.suggestions.map((suggestion, idx) => (
                                  <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: idx * 0.1 }}
                                  >
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleSendMessage(suggestion)}
                                      className="w-full justify-start text-left text-xs h-auto py-1.5 px-2 border-primary/30 hover:border-primary hover:bg-primary/10 text-gray-300 hover:text-white"
                                    >
                                      <Sparkles className="h-3 w-3 mr-1.5 text-primary flex-shrink-0" />
                                      <span className="text-xs">{suggestion}</span>
                                    </Button>
                                  </motion.div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                    {isTyping && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex items-start space-x-2"
                      >
                        <div className="h-7 w-7 rounded-full bg-gradient-to-r from-primary/20 to-amber-400/20 flex items-center justify-center">
                          <Bot className="h-4 w-4 text-primary" />
                        </div>
                        <div className="bg-gray-800/80 rounded-2xl px-3 py-2 border border-primary/20">
                          <div className="flex space-x-1">
                            <motion.div
                              className="h-2 w-2 bg-primary rounded-full"
                              animate={{ scale: [1, 1.5, 1] }}
                              transition={{ duration: 1, repeat: Infinity, delay: 0 }}
                            />
                            <motion.div
                              className="h-2 w-2 bg-primary rounded-full"
                              animate={{ scale: [1, 1.5, 1] }}
                              transition={{ duration: 1, repeat: Infinity, delay: 0.2 }}
                            />
                            <motion.div
                              className="h-2 w-2 bg-primary rounded-full"
                              animate={{ scale: [1, 1.5, 1] }}
                              transition={{ duration: 1, repeat: Infinity, delay: 0.4 }}
                            />
                          </div>
                        </div>
                      </motion.div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>
              </CardContent>

              {/* Input */}
              <div className="border-t border-primary/20 p-3 bg-black/50">
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={toggleVoiceInput}
                    className={`h-9 w-9 p-0 ${isListening ? 'text-red-500 bg-red-500/10' : 'text-gray-400 hover:text-primary'}`}
                    disabled={!recognitionRef.current}
                  >
                    {isListening ? <Mic className="h-4 w-4 animate-pulse" /> : <MicOff className="h-4 w-4" />}
                  </Button>
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder={language === 'en' ? "Ask me anything..." : language === 'hi' ? "मुझसे कुछ भी पूछें..." : language === 'pa' ? "ਮੈਨੂੰ ਕੁਝ ਵੀ ਪੁੱਛੋ..." : language === 'ne' ? "मलाई जे पनि सोध्नुहोस्..." : "Magtanong ng kahit ano..."}
                    className="flex-1 h-9 text-sm bg-gray-800/50 border-primary/30 text-white placeholder:text-gray-500 focus:border-primary"
                  />
                  <Button
                    onClick={() => handleSendMessage()}
                    disabled={!inputValue.trim()}
                    className="h-9 bg-gradient-to-r from-primary to-amber-400 text-black hover:from-amber-400 hover:to-primary disabled:opacity-50"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-1.5 text-center">
                  Powered by JioWW AI • Professional Immigration Consultation
                </p>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
