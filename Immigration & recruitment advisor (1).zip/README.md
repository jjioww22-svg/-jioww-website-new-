
  # Immigration & recruitment advisor

  This is a code bundle for Immigration & recruitment advisor. The original project is available at https://www.figma.com/design/RfVRb8ZIihDnSeQuXkgssZ/Immigration---recruitment-advisor.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  